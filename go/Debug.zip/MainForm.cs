﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace WinFormApp
{
    public partial class MainForm : Form
    {
        private readonly Dictionary<FontStyle, Font> fonts;

        public MainForm()
        {
            InitializeComponent();

            fonts = new Dictionary<FontStyle, Font>
                {
                    {FontStyle.Regular, Font},
                    {FontStyle.Bold, new Font(Font, FontStyle.Bold)},
                    {FontStyle.Italic, new Font(Font, FontStyle.Italic)},
                    {FontStyle.Underline, new Font(Font, FontStyle.Underline)},
                    {
                        FontStyle.Bold | FontStyle.Italic | FontStyle.Underline,
                            new Font(Font, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline)
                    }
                };
            pictureBox.Paint += PictureBoxOnPaint;
        }

        private void PictureBoxResize(object sender, EventArgs e)
        {
            pictureBox.Invalidate();
        }

        private void PictureBoxOnPaint(object sender, PaintEventArgs e)
        {
            const int pointsCount = 24;
            var rnd = new Random();
            var points = new PointF[pointsCount + 2];
            var y = rnd.Next(32);
            var step = 80f / pointsCount;
            var x = 0f;

            for (var i = 0; i < pointsCount; i++)
            {
                var delta = rnd.Next(21) - 10;
                y += delta;
                if (y < 0) y = 0;
                if (y > 31) y = 31;

                points[i] = new PointF(x, y);
                x += step;
            }
            points[pointsCount] = new PointF(80 - 1, 32 - 1);
            points[pointsCount + 1] = new PointF(0, 32 - 1);

            // создать картинку с графиком
            using (var brush = new HatchBrush(HatchStyle.DarkVertical, Color.CornflowerBlue, SystemColors.ButtonFace))
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.FillPolygon(brush, points);
            }
        }

        private void TwoStylesButton1Click(object sender, EventArgs e)
        {
            var dlg = new FolderBrowserDialog();
            if (dlg.ShowDialog() != DialogResult.OK) return;

            var sb = new StringBuilder();

            foreach (var fileName in Directory.GetFiles(dlg.SelectedPath, "*.txt"))
            {
                var fileNameOnly = Path.GetFileNameWithoutExtension(fileName);
                var numbers = fileNameOnly.ToIntArrayUniform();
                if (numbers.Length != 1) continue;

                ParseFile(fileName, numbers[0], sb);
            }

            using (var sw = new StreamWriter(dlg.SelectedPath + "\\tickets.htm", false, Encoding.GetEncoding(1251)))
            {
                sw.Write(sb);
            }
        }

        private void ParseFile(string fileName, int sheetNum, StringBuilder sb)
        {
            sb.AppendLine("    <h3>Билет №" + sheetNum + "</h3>");
            sb.AppendLine("    <div id=\"ticket" + sheetNum + "\">");
            var questNum = 1;

            using (var sr = new StreamReader(fileName, Encoding.GetEncoding(1251)))
            {
                while (!sr.EndOfStream)
                {
                    var line = sr.ReadLine();
                    if (string.IsNullOrEmpty(line)) continue;
                    line = line.Trim();
                    if (line.Length < 3) continue;

                    var preffix = "";
                    if (line.StartsWith("А.") || line.StartsWith("Б.") || line.StartsWith("В."))
                        preffix = line[0].ToString();

                    if (string.IsNullOrEmpty(preffix))
                    {
                        if (questNum > 1)
                            sb.AppendLine("      </ul>");
                        sb.AppendLine("      <span id=\"s" + sheetNum + "q" + questNum + "\">" + questNum + ") " + line + "</span>");
                        sb.AppendLine("      <ul>");
                        questNum++;
                        continue;
                    }
                    sb.AppendLine("        <li>" + line + "</li>");
                }
            }

            sb.AppendLine("    </div>");
        }
    }

    public static class GraphicsExtensions
    {
        private static readonly char[] lineSeparator = new [] { '\n' };

        /// <summary>
        /// для простоты - каждая строка текста имеет свой формат
        /// необязательные модификаторы вида [b][i][u][#RRGGBB] идут _в начале_ строки
        /// [b][i][u][#ff00e6]This is a bold/italic/underlined magenta line of text
        /// </summary>
        public static SizeF MeasureFormattedText(this Graphics g, string text, Dictionary<FontStyle, Font> fonts, Font defaultFont)
        {
            if (string.IsNullOrEmpty(text)) return new SizeF(0, 0);
            var lines = text.Split(lineSeparator, StringSplitOptions.RemoveEmptyEntries);

            var totalHeight = 0f;
            var totalWidth = 0f;

            foreach (var line in lines)
            {
                FontStyle fontStyle;
                Color? fontColor;
                
                var pureLine = GetLineModifiers(line, out fontStyle, out fontColor);
                Font font;
                if (!fonts.TryGetValue(fontStyle, out font))
                    font = defaultFont;
                var dH = font.GetHeight(g);
                totalHeight += dH;
                
                if (string.IsNullOrEmpty(pureLine)) continue;
                var sz = g.MeasureString(pureLine, font);
                if (sz.Width > totalWidth) totalWidth = sz.Width;
            }

            return new SizeF(totalWidth, totalHeight);
        }

        public static void DrawFormattedText(this Graphics g, 
            float x, float y,
            Brush brush,
            string text, Dictionary<FontStyle, Font> fonts, Font defaultFont)
        {
            if (string.IsNullOrEmpty(text)) return;
            var lines = text.Split(lineSeparator, StringSplitOptions.RemoveEmptyEntries);
            var totalHeight = 0f;

            foreach (var line in lines)
            {
                FontStyle fontStyle;
                Color? fontColor;

                var pureLine = GetLineModifiers(line, out fontStyle, out fontColor);
                Font font;
                if (!fonts.TryGetValue(fontStyle, out font))
                    font = defaultFont;

                g.DrawString(pureLine, font, brush, x, y + totalHeight);
                
                var dH = font.GetHeight(g);
                totalHeight += dH;
            }
        }

        private static string GetLineModifiers(string line, out FontStyle style, out Color? color)
        {
            // [b][i][u][#ff00e6]This is a bold/italic/underlined magenta line of text
            style = FontStyle.Regular;
            color = null;
            if (string.IsNullOrEmpty(line)) return line;
            var clLen = "[#RRGGBB]".Length;

            while (true)
            {
                if (line.StartsWith("[b]"))
                {
                    line = line.Substring("[b]".Length);
                    style = style | FontStyle.Bold;
                    continue;
                }
                if (line.StartsWith("[i]"))
                {
                    line = line.Substring("[i]".Length);
                    style = style | FontStyle.Italic;
                    continue;
                }
                if (line.StartsWith("[u]"))
                {
                    line = line.Substring("[u]".Length);
                    style = style | FontStyle.Underline;
                    continue;
                }
                if (line.StartsWith("[#"))
                {
                    if (line.Length <= clLen) break;
                    var rgbColor = int.Parse(line.Substring(2, 6), 
                        System.Globalization.NumberStyles.AllowHexSpecifier);
                    //rgbColor += 0xFF000000;
                    color = Color.FromArgb(rgbColor);
                    line = line.Substring(clLen);
                    continue;
                }
                break;
            }

            return line;
        }
    }
}
